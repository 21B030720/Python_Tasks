def Histogram(l):
    for i in l:
        print("*" * int(i))
m = Histogram(input().split())