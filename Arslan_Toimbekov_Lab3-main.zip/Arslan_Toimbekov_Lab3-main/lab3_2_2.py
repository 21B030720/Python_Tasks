def Temperature(F):
    print( (5 / 9) * (int(F) - 32) )
Temperature(input())