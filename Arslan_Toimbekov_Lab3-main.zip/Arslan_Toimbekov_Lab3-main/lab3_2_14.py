from lab3_2_13 import GuessTheNumber
m = GuessTheNumber()