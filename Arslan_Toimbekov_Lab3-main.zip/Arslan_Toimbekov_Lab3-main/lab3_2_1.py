def ounces(a):
    print(int(a) * 28.3495231)
ounces(input())