import psycopg2
from lab11_1 import *
from lab11_2 import *
from lab11_3 import *
from lab11_4 import *
from lab11_5 import *


#def
#data_create_or_update("Abu", "Bakir", 30)
#data_3('number.csv')
#data_get(421)
#data_delete('Abu')
#data_4(3)
