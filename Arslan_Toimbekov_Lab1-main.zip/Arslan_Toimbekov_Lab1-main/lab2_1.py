l = []
l = input()
sum = 0
for i in range(len(l)):
    sum += l