a = int(input())
l = []
for i in range(a):
    l = input(.split(" "))
    if len(l) == 2:
        c, s = l
        c = int(c)
        s = str(s)
    else:
        if l.empty():
            l.pop(0)


