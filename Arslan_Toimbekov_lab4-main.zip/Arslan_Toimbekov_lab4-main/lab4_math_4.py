import math
h = float(input())
a = float(input())
print(a*h)