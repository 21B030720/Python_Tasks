import math
h = float(input())
a = float(input())
b = float(input())
print(  (a+b)/2*h   )