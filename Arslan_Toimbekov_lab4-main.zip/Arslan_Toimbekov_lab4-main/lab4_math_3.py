import math
num = float(input())
a = float(input())
print(num*a*a/   (4*math.tan(math.pi/num))    )
m = num*a*a/   (4*math.tan(math.pi/num))
m = round(m)
print(m)